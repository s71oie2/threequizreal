from django.apps import AppConfig


class PlantConfig(AppConfig):
    name = 'plant'
